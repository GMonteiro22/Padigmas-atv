package Objeto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Representa o tabuleiro 9x9 do Sudoku. Encapsula a grade (equivalente ao
 * "int tabuleiro[9][9]" global do código em C) e as operações básicas sobre
 * ela: ler célula, escrever célula, verificar completude, comparar com
 * outro tabuleiro e carregar de um arquivo texto.
 *
 * Corresponde, no código em C, à variável global "tabuleiro" mais a função
 * "lerTabuleiro".
 */
public class Tabuleiro {

    private final int[][] grade;

    public Tabuleiro() {
        this.grade = new int[9][9];
    }

    /**
     * Retorna o valor da célula (0 = vazia, 1-9 = preenchida).
     */
    public int getValor(int linha, int coluna) {
        return grade[linha][coluna];
    }

    /**
     * Define o valor de uma célula.
     */
    public void setValor(int linha, int coluna, int valor) {
        grade[linha][coluna] = valor;
    }

    /**
     * Verifica se todas as 81 células estão preenchidas (nenhum valor 0).
     *
     * Equivale à função "estaCompleto" do código em C.
     */
    public boolean estaCompleto() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (grade[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Verifica se "resposta" respeita todas as pistas fixas deste
     * tabuleiro: em toda célula onde este tabuleiro tem um valor diferente
     * de zero, "resposta" precisa ter exatamente o mesmo valor. Células
     * vazias neste tabuleiro não impõem nenhuma restrição sobre "resposta".
     *
     * Equivale, no código em C, ao laço de "respeitaPistas" dentro do
     * case 3 do main - mas ali era uma comparação solta entre duas
     * matrizes; aqui é uma pergunta que o próprio Tabuleiro sabe responder
     * sobre si mesmo, em relação a outro Tabuleiro.
     */
    public boolean respeitaPistasDe(Tabuleiro resposta) {
        for (int linha = 0; linha < 9; linha++) {
            for (int coluna = 0; coluna < 9; coluna++) {
                int valorFixo = this.getValor(linha, coluna);
                if (valorFixo != 0 && valorFixo != resposta.getValor(linha, coluna)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Lê um tabuleiro 9x9 a partir de um arquivo texto, no mesmo formato
     * usado pela versão em C: 9 linhas, cada uma com exatamente 9
     * caracteres, sendo '0' célula vazia e '1'-'9' célula preenchida.
     *
     * Equivale à função "lerTabuleiro" do código em C. Valida:
     *  - o arquivo existe e pode ser aberto;
     *  - existem exatamente 9 linhas;
     *  - cada linha tem exatamente 9 caracteres;
     *  - cada caractere é '0'-'9'.
     *
     * @throws IOException se o arquivo não puder ser lido ou estiver em
     *         formato inválido (dimensão errada, caractere inválido, etc.)
     */
    public static Tabuleiro lerDeArquivo(String caminhoArquivo) throws IOException {
        Tabuleiro tabuleiro = new Tabuleiro();

        try (BufferedReader leitor = new BufferedReader(new FileReader(caminhoArquivo))) {
            for (int i = 0; i < 9; i++) {
                String linha = leitor.readLine();

                if (linha == null) {
                    throw new IOException("arquivo com menos de 9 linhas.");
                }

                // Garante que a linha tem exatamente 9 caracteres. Isso impede,
                // por exemplo, que um valor de dois dígitos (ex: "10") seja lido
                // como se fossem duas células separadas ("1" e "0") - a linha
                // inteira é rejeitada em vez de ser silenciosamente mal
                // interpretada. readLine() já remove a quebra de linha, então
                // não é preciso descontar "\r"/"\n" como no C.
                if (linha.length() != 9) {
                    throw new IOException("linha " + (i + 1) + " deve conter exatamente 9 caracteres (encontrado "
                            + linha.length() + ").");
                }

                for (int j = 0; j < 9; j++) {
                    char c = linha.charAt(j);
                    if (c == '0') {
                        tabuleiro.grade[i][j] = 0;
                    } else if (c >= '1' && c <= '9') {
                        tabuleiro.grade[i][j] = c - '0';
                    } else {
                        throw new IOException("caractere invalido na linha " + (i + 1) + ".");
                    }
                }
            }
        } catch (java.io.FileNotFoundException e) {
            throw new IOException("nao foi possivel abrir o arquivo.");
        }

        return tabuleiro;
    }

    /**
     * Retorna uma representação textual do tabuleiro, com separadores
     * visuais a cada 3 linhas/colunas (blocos 3x3).
     *
     * Equivale à função "imprimirTabuleiro" do código em C.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if ((j + 1) % 3 == 0) {
                    sb.append(grade[i][j]).append(" |");
                } else {
                    sb.append(grade[i][j]).append(" ");
                }
            }
            sb.append("\n");

            if ((i + 1) % 3 == 0) {
                sb.append("---------------------\n");
            }
        }

        return sb.toString();
    }
}