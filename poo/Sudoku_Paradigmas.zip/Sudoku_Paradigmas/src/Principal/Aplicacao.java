package Principal;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import Objeto.Tabuleiro;
import resolver.*;
import validar.ErroValidacao;
import validar.Validador;

/**
 * Ponto de entrada do programa. Lê o tabuleiro de "tabuleiro.txt", pergunta
 * ao usuário qual ação deseja executar (validar, resolver ou validar
 * resposta) e direciona a execução para o bloco correspondente do switch.
 *
 * Equivale à função "main" do código em C.
 */
public class Aplicacao {

    public static void main(String[] args) {
        Tabuleiro tabuleiro;
        try {
            tabuleiro = Tabuleiro.lerDeArquivo("tabuleiro.txt");
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
            return;
        }

        System.out.println(tabuleiro);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite a seguir qual acao queira fazer:\n1-Validar tabuleiro\n2-Resolver tabuleiro\n3-Validar resposta(insira o tabuleiro resolvido no arquivo \"tabuleiro2.txt\")\nDigite aqui:");
        int decisao = scanner.nextInt();

        while (decisao != 1 && decisao != 2 && decisao != 3) {
            System.out.print("Acao nao encontrada, tente novamente:");
            decisao = scanner.nextInt();
        }

        Validador validador = new Validador();

        switch (decisao) {
            case 1: // Validação de tabuleiro.
            {
                List<ErroValidacao> erros = validador.validar(tabuleiro);

                if (erros.isEmpty()) {
                    if (tabuleiro.estaCompleto()) {
                        System.out.println("Tabuleiro valido e completo!");
                    } else {
                        System.out.println("Tabuleiro valido!");
                    }
                } else {
                    System.out.println("Os erros encontrados no tabuleiro foram:");
                    for (ErroValidacao erro : erros) {
                        System.out.println(erro);
                    }
                }

                break;
            }

            case 2: // Resolução de tabuleiro.
            {
                List<ErroValidacao> erros = validador.validar(tabuleiro);

                if (!erros.isEmpty()) {
                    System.out.println("Tabuleiro invalido, nao e possivel resolver:");
                    for (ErroValidacao erro : erros) {
                        System.out.println(erro);
                    }
                    break;
                }

                if (tabuleiro.estaCompleto()) {
                    System.out.println("O tabuleiro ja estava completo e valido. Nenhuma busca foi necessaria.");
                    System.out.println(tabuleiro);
                    break;
                }

                Tabuleiro resolvido = SudokuSolver.resolver(tabuleiro);

                if (resolvido != null) {
                    System.out.println("Solucao encontrada:");
                    System.out.println(resolvido);
                } else {
                    System.out.println("Este tabuleiro nao possui solucao.");
                }

                break;
            }

            case 3: // Validação de resposta.
            {
                Tabuleiro tabuleiroResposta;
                try {
                    tabuleiroResposta = Tabuleiro.lerDeArquivo("tabuleiro2.txt");
                } catch (IOException e) {
                    System.out.println("Erro: " + e.getMessage());
                    break;
                }

                boolean completo = tabuleiroResposta.estaCompleto();
                boolean respeitaPistas = tabuleiro.respeitaPistasDe(tabuleiroResposta);
                List<ErroValidacao> erros = validador.validar(tabuleiroResposta);

                if (!completo) {
                    System.out.println("Resposta invalida: existem celulas vazias.");
                } else if (!respeitaPistas) {
                    System.out.println("Resposta invalida: nao respeita os valores originais do tabuleiro.");
                } else if (!erros.isEmpty()) {
                    System.out.println("Resposta invalida: ha conflitos.");
                    for (ErroValidacao erro : erros) {
                        System.out.println(erro);
                    }
                } else {
                    System.out.println("Resposta valida! Parabens.");
                }

                break;
            }
        }

        scanner.close();
    }
}