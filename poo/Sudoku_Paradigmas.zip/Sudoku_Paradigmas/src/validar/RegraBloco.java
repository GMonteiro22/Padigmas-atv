package validar;

import java.util.ArrayList;
import java.util.List;

import Objeto.Tabuleiro;

/**
 * Verifica se algum dígito se repete dentro do mesmo bloco 3x3.
 */
public class RegraBloco implements RegraValidacao {

    @Override
    public List<ErroValidacao> verificar(Tabuleiro tabuleiro) {
        List<ErroValidacao> erros = new ArrayList<>();

        for (int bloco = 0; bloco < 9; bloco++) {
            int linhaInicio = (bloco / 3) * 3;
            int colunaInicio = (bloco % 3) * 3;

            for (int digito = 1; digito <= 9; digito++) {
                List<int[]> posicoesEncontradas = new ArrayList<>();

                for (int deltaLinha = 0; deltaLinha < 3; deltaLinha++) {
                    for (int deltaColuna = 0; deltaColuna < 3; deltaColuna++) {
                        int linha = linhaInicio + deltaLinha;
                        int coluna = colunaInicio + deltaColuna;

                        if (tabuleiro.getValor(linha, coluna) == digito) {
                            posicoesEncontradas.add(new int[] { linha, coluna });
                        }
                    }
                }

                for (int a = 0; a < posicoesEncontradas.size(); a++) {
                    for (int b = a + 1; b < posicoesEncontradas.size(); b++) {
                        int[] posicao1 = posicoesEncontradas.get(a);
                        int[] posicao2 = posicoesEncontradas.get(b);
                        erros.add(new ErroValidacao(digito, posicao1[0], posicao1[1],
                                posicao2[0], posicao2[1]));
                    }
                }
            }
        }

        return erros;
    }
}