package validar;

import java.util.ArrayList;
import java.util.List;

import Objeto.Tabuleiro;

/**
 * Verifica se algum dígito se repete dentro da mesma coluna.
 */
public class RegraColuna implements RegraValidacao {

    @Override
    public List<ErroValidacao> verificar(Tabuleiro tabuleiro) {
        List<ErroValidacao> erros = new ArrayList<>();

        for (int coluna = 0; coluna < 9; coluna++) {
            for (int digito = 1; digito <= 9; digito++) {
                List<Integer> linhasEncontradas = new ArrayList<>();

                for (int linha = 0; linha < 9; linha++) {
                    if (tabuleiro.getValor(linha, coluna) == digito) {
                        linhasEncontradas.add(linha);
                    }
                }

                for (int a = 0; a < linhasEncontradas.size(); a++) {
                    for (int b = a + 1; b < linhasEncontradas.size(); b++) {
                        erros.add(new ErroValidacao(digito, linhasEncontradas.get(a), coluna,
                                linhasEncontradas.get(b), coluna));
                    }
                }
            }
        }

        return erros;
    }
}