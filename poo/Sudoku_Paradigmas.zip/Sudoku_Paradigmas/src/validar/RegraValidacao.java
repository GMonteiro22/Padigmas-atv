package validar;

import java.util.List;

import Objeto.Tabuleiro;

/**
 * Uma regra individual de validação do Sudoku. Cada implementação sabe
 * verificar apenas a sua própria dimensão da regra de não-repetição
 * (linha, coluna ou bloco), devolvendo os conflitos que encontrar.
 *
 * O Validador não sabe, e não precisa saber, quantas regras existem nem
 * como cada uma funciona por dentro - ele só chama verificar()
 * polimorficamente sobre uma lista de RegraValidacao. Adicionar uma nova
 * regra no futuro (por exemplo, as duas diagonais de um "X-Sudoku")
 * significa criar uma nova classe implementando esta interface, sem tocar
 * em nenhuma das classes já existentes.
 */
public interface RegraValidacao {

    List<ErroValidacao> verificar(Tabuleiro tabuleiro);
}