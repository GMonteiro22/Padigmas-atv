package validar;

import java.util.ArrayList;
import java.util.List;

import Objeto.Tabuleiro;

/**
 * Valida um Tabuleiro contra as três regras do Sudoku, delegando cada
 * dimensão da verificação (linha, coluna, bloco) a um objeto RegraValidacao
 * independente.
 *
 * Diferente da versão anterior (um único método estático que já sabia,
 * por dentro, as três regras), este Validador agora é um objeto de verdade:
 * ele guarda um estado (a lista de regras que compõem sua validação) e
 * delega o trabalho polimorficamente, sem saber como cada regra funciona
 * por dentro. Isso também resolve o requisito de extensão do sistema: para
 * adicionar uma nova regra (por exemplo, as diagonais de um "X-Sudoku"),
 * basta chamar adicionarRegra() com uma nova implementação de
 * RegraValidacao - nenhuma linha desta classe precisa mudar.
 */
public class Validador {

    private final List<RegraValidacao> regras;

    /**
     * Cria um Validador já com as três regras clássicas do Sudoku
     * (linha, coluna e bloco).
     */
    public Validador() {
        this.regras = new ArrayList<>();
        this.regras.add(new RegraLinha());
        this.regras.add(new RegraColuna());
        this.regras.add(new RegraBloco());
    }

    /**
     * Adiciona uma regra extra de validação, além das três padrão.
     */
    public void adicionarRegra(RegraValidacao regra) {
        this.regras.add(regra);
    }

    /**
     * Executa todas as regras cadastradas sobre o tabuleiro informado e
     * devolve a lista combinada de conflitos encontrados. Lista vazia
     * significa tabuleiro válido (sem conflitos).
     */
    public List<ErroValidacao> validar(Tabuleiro tabuleiro) {
        List<ErroValidacao> erros = new ArrayList<>();

        for (RegraValidacao regra : regras) {
            erros.addAll(regra.verificar(tabuleiro));
        }

        return erros;
    }
}