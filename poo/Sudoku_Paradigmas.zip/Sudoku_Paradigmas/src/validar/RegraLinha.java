package validar;

import java.util.ArrayList;
import java.util.List;

import Objeto.Tabuleiro;

/**
 * Verifica se algum dígito se repete dentro da mesma linha.
 */
public class RegraLinha implements RegraValidacao {

    @Override
    public List<ErroValidacao> verificar(Tabuleiro tabuleiro) {
        List<ErroValidacao> erros = new ArrayList<>();

        for (int linha = 0; linha < 9; linha++) {
            for (int digito = 1; digito <= 9; digito++) {
                List<Integer> colunasEncontradas = new ArrayList<>();

                for (int coluna = 0; coluna < 9; coluna++) {
                    if (tabuleiro.getValor(linha, coluna) == digito) {
                        colunasEncontradas.add(coluna);
                    }
                }

                for (int a = 0; a < colunasEncontradas.size(); a++) {
                    for (int b = a + 1; b < colunasEncontradas.size(); b++) {
                        erros.add(new ErroValidacao(digito, linha, colunasEncontradas.get(a),
                                linha, colunasEncontradas.get(b)));
                    }
                }
            }
        }

        return erros;
    }
}