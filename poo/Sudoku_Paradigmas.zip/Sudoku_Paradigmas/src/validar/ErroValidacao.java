package validar;

/**
 * Representa um único conflito encontrado na validação de um tabuleiro:
 * um dígito repetido entre duas células, por violar a regra de linha,
 * coluna ou bloco.
 *
 * Equivale, no código em C, ao nó da lista encadeada "NoE" (struct Noerro).
 * Aqui não precisamos de lista encadeada manual - o Validador vai devolver
 * uma "List<ErroValidacao>" (ArrayList) pronta da biblioteca padrão do Java.
 */
public class ErroValidacao {

    private final int digito;
    private final int linha1;
    private final int coluna1;
    private final int linha2;
    private final int coluna2;

    public ErroValidacao(int digito, int linha1, int coluna1, int linha2, int coluna2) {
        this.digito = digito;
        this.linha1 = linha1;
        this.coluna1 = coluna1;
        this.linha2 = linha2;
        this.coluna2 = coluna2;
    }

    public int getDigito() {
        return digito;
    }

    /**
     * Formata o erro no mesmo padrão usado pela versão em C:
     * "O digito 5 nos pontos [1,1] - [1,2]" (índices de 1 a 9).
     *
     * Equivale à função "PrintErrosTab" do código em C (a parte de formatação
     * de uma única linha de erro).
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("O digito ").append(this.digito).append(" nos pontos ");
        sb.append("[").append(this.linha1 + 1).append(",").append(this.coluna1 + 1).append("] - [");
        sb.append(this.linha2 + 1).append(",").append(this.coluna2 + 1).append("]");

        return sb.toString();
    }
}