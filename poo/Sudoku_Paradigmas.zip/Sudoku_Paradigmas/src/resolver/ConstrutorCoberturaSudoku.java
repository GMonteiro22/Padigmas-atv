package resolver;

import java.util.ArrayList;
import java.util.List;

import Objeto.Tabuleiro;

/**
 * Traduz um Tabuleiro de Sudoku para uma MatrizCoberturaExata (324 colunas,
 * até 729 linhas possíveis), e traduz a solução encontrada de volta para um
 * Tabuleiro preenchido.
 *
 * Esta classe concentra TODO o conhecimento específico de Sudoku usado na
 * resolução (linha, coluna, bloco, dígito) - a MatrizCoberturaExata e o
 * Algorithm X em si não sabem nada disso. É essa separação que substitui,
 * de forma bem mais desacoplada, o que "resolverSudoku" fazia sozinho no
 * código em C.
 *
 * Esquema de colunas (324 no total):
 *  -   0 a  80: uma célula (linha, coluna) está preenchida.
 *  -  81 a 161: um dígito aparece nesta linha.
 *  - 162 a 242: um dígito aparece nesta coluna.
 *  - 243 a 323: um dígito aparece neste bloco.
 *
 * Esquema de linhas (até 729): cada linha representa "colocar o dígito d
 * na célula (linha, coluna)", identificada por um único inteiro
 * idLinha = linha*81 + coluna*9 + (d-1).
 */
public class ConstrutorCoberturaSudoku {

    private static final int TOTAL_COLUNAS = 324;

    /**
     * Constrói a MatrizCoberturaExata correspondente ao tabuleiro
     * informado. Células já preenchidas geram apenas uma linha (o valor
     * fixo); células vazias geram até 9 linhas (uma por dígito candidato).
     */
    public MatrizCoberturaExata construir(Tabuleiro tabuleiro) {
        List<String> nomesColunas = new ArrayList<>(TOTAL_COLUNAS);

        // 0 a 80: "celula-L-C" está preenchida.
        for (int linha = 0; linha < 9; linha++) {
            for (int coluna = 0; coluna < 9; coluna++) {
                nomesColunas.add("celula-" + (linha + 1) + "-" + (coluna + 1));
            }
        }
        // 81 a 161: um dígito aparece na linha L.
        for (int linha = 0; linha < 9; linha++) {
            for (int digito = 1; digito <= 9; digito++) {
                nomesColunas.add("linha-" + (linha + 1) + "-digito-" + digito);
            }
        }
        // 162 a 242: um dígito aparece na coluna C.
        for (int coluna = 0; coluna < 9; coluna++) {
            for (int digito = 1; digito <= 9; digito++) {
                nomesColunas.add("coluna-" + (coluna + 1) + "-digito-" + digito);
            }
        }
        // 243 a 323: um dígito aparece no bloco B.
        for (int bloco = 0; bloco < 9; bloco++) {
            for (int digito = 1; digito <= 9; digito++) {
                nomesColunas.add("bloco-" + (bloco + 1) + "-digito-" + digito);
            }
        }

        MatrizCoberturaExata matriz = new MatrizCoberturaExata(nomesColunas);

        for (int linha = 0; linha < 9; linha++) {
            for (int coluna = 0; coluna < 9; coluna++) {
                int valorFixo = tabuleiro.getValor(linha, coluna);

                // Célula já preenchida: só existe UMA jogada possível (o
                // próprio valor fixo). Célula vazia: as 9 jogadas (1 a 9)
                // entram como candidatas - é o Algorithm X quem decide,
                // durante a busca, qual delas sobrevive.
                int primeiroDigito = (valorFixo != 0) ? valorFixo : 1;
                int ultimoDigito = (valorFixo != 0) ? valorFixo : 9;

                for (int digito = primeiroDigito; digito <= ultimoDigito; digito++) {
                    int idLinha = linha * 81 + coluna * 9 + (digito - 1);
                    int bloco = indiceBloco(linha, coluna);

                    List<Integer> indicesColunas = new ArrayList<>(4);
                    indicesColunas.add(linha * 9 + coluna);
                    indicesColunas.add(81 + linha * 9 + (digito - 1));
                    indicesColunas.add(162 + coluna * 9 + (digito - 1));
                    indicesColunas.add(243 + bloco * 9 + (digito - 1));

                    matriz.adicionarLinha(idLinha, indicesColunas);
                }
            }
        }

        return matriz;
    }

    /**
     * Traduz a lista de nós solução (devolvida por
     * MatrizCoberturaExata.buscar()) de volta para um novo Tabuleiro
     * preenchido. Não modifica o tabuleiro original - devolve uma nova
     * instância, o que evita mutação do objeto de entrada.
     */
    public Tabuleiro aplicarSolucao(List<No> solucao) {
        Tabuleiro resultado = new Tabuleiro();

        for (No no : solucao) {
            int idLinha = no.idLinha;

            int linha = idLinha / 81;
            int resto = idLinha % 81;
            int coluna = resto / 9;
            int digito = (resto % 9) + 1;

            resultado.setValor(linha, coluna, digito);
        }

        return resultado;
    }

    /**
     * Calcula o índice do bloco 3x3 (0 a 8) a partir de linha/coluna.
     * Mesma fórmula usada em Validador - método utilitário compartilhado.
     */
    private int indiceBloco(int linha, int coluna) {
        return (linha / 3) * 3 + (coluna / 3);
    }
}