package resolver;

/**
 * Um nó da malha toroidal de Dancing Links. Cada nó sabe apenas se
 * relacionar com seus quatro vizinhos (esquerda, direita, cima, baixo) e
 * com a coluna à qual pertence.
 *
 * Este nó representa um único "1" na matriz de cobertura exata: a presença
 * de um nó em (linha X, coluna Y) significa que a linha X satisfaz a
 * restrição da coluna Y. Não existe equivalente direto no código em C —
 * lá, as restrições eram checadas com bitmasks e laços sobre uma matriz
 * comum, sem uma estrutura de dados dedicada para representá-las.
 */
public class No {

    public No esquerda;
    public No direita;
    public No cima;
    public No baixo;
    public ColunaCabecalho coluna;

    /**
     * Identifica a qual linha da matriz de cobertura este nó pertence
     * (ou seja, qual jogada "colocar dígito D na célula (l,c)" ele
     * representa). Usado para reconstruir a solução ao final da busca.
     */
    public int idLinha;

    /**
     * Insere este nó imediatamente à esquerda do nó informado, ajustando
     * os ponteiros de ambos os lados (a malha é circular).
     */
    public void inserirAEsquerdaDe(No outro) {
        this.esquerda = outro.esquerda;
        this.direita = outro;
        outro.esquerda.direita = this;
        outro.esquerda = this;
    }

    /**
     * Insere este nó imediatamente abaixo do nó informado, ajustando os
     * ponteiros de ambos os lados (a malha é circular).
     */
    public void inserirAbaixoDe(No outro) {
    	this.baixo = outro.baixo;
    	this.cima = outro;
    	outro.baixo.cima = this;
    	outro.baixo = this;
      
    }

    /**
     * Remove este nó da sua linha horizontal (usado ao cobrir uma coluna:
     * cada nó da coluna precisa remover os outros nós da mesma linha).
     */
    public void removerDaLinha() {
    	this.esquerda.direita = direita;
    	this.direita.esquerda = esquerda;
       
    }

    /**
     * Reinsere este nó na sua linha horizontal (usado ao descobrir uma
     * coluna).
     */
    public void reinserirNaLinha() {
    	this.esquerda.direita = this;
    	this.direita.esquerda = this;
        
    }

    /**
     * Remove este nó da sua coluna vertical (usado ao cobrir uma linha
     * inteira: cada nó da linha precisa remover os outros nós da mesma
     * coluna).
     */
    public void removerDaColuna() {
    	this.cima.baixo = baixo;
    	this.baixo.cima = cima;
     
    }

    /**
     * Reinsere este nó na sua coluna vertical (usado ao descobrir uma
     * linha, desfazendo removerDaColuna).
     */
    public void reinserirNaColuna() {
    	this.cima.baixo = this;
    	this.baixo.cima = this;
        // TODO: cima.baixo = this; baixo.cima = this;
    }
}