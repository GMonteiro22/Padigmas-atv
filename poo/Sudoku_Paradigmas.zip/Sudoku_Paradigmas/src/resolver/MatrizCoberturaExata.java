package resolver;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementação genérica do Algorithm X de Donald Knuth, usando Dancing
 * Links. Esta classe não sabe nada sobre Sudoku - ela resolve qualquer
 * problema de cobertura exata que tenha sido montado dentro dela como uma
 * malha de colunas e nós.
 *
 * Essa separação (algoritmo genérico vs. tradução do domínio) é a principal
 * diferença estrutural em relação ao "resolverSudoku" do código em C, que
 * misturava, na mesma função recursiva, tanto a lógica de busca quanto o
 * conhecimento das regras específicas do Sudoku (linha, coluna, bloco).
 */
public class MatrizCoberturaExata {

    private final ColunaCabecalho cabecalhoRaiz;
    private final List<ColunaCabecalho> colunas;

    /**
     * Cria uma matriz de cobertura exata vazia, com uma coluna para cada
     * nome informado (na ordem dada).
     */
    public MatrizCoberturaExata(List<String> nomesColunas) {
        this.colunas = new ArrayList<>();
        this.cabecalhoRaiz = new ColunaCabecalho("raiz");

        for (String nome : nomesColunas) {
            ColunaCabecalho coluna = new ColunaCabecalho(nome);
            this.colunas.add(coluna);
            coluna.inserirAEsquerdaDe(this.cabecalhoRaiz);
        }
    }

    /**
     * Adiciona uma linha à matriz: uma lista de índices de coluna que essa
     * linha cobre. Cria um nó para cada índice, encadeando-os entre si
     * (na linha) e em suas respectivas colunas (na vertical).
     *
     * @param idLinha identificador da linha (usado depois para traduzir a
     *                solução de volta ao domínio do Sudoku)
     * @param indicesColunas quais colunas esta linha cobre
     */
    public void adicionarLinha(int idLinha, List<Integer> indicesColunas) {
        No primeiroDaLinha = null;

        for (int indice : indicesColunas) {
            No novo = new No();
            novo.idLinha = idLinha;

            ColunaCabecalho coluna = this.colunas.get(indice);
            novo.coluna = coluna; // essencial: cobrir()/descobrir() usam "no.coluna" para achar a coluna do nó.

            // Insere "novo" logo acima do cabeçalho (ou seja, como o novo
            // último nó da coluna) - coluna.cima é sempre o nó mais recente
            // dessa coluna, já que a lista é circular.
            novo.inserirAbaixoDe(coluna.cima);
            coluna.tamanho++;

            if (primeiroDaLinha == null) {
                // Primeiro nó desta linha: ainda não há vizinho horizontal
                // para se ligar, então ele se auto-referencia (mesma ideia
                // usada no cabecalhoRaiz antes da primeira coluna entrar).
                primeiroDaLinha = novo;
                novo.esquerda = novo;
                novo.direita = novo;
            } else {
                novo.inserirAEsquerdaDe(primeiroDaLinha);
            }
        }
    }

    /**
     * Escolhe a próxima coluna a explorar, sempre a de menor "tamanho"
     * (menos linhas cobrindo aquela restrição). Equivale, em espírito, à
     * heurística MRV usada em "escolherCelula" no código em C: reduzir o
     * fator de ramificação da busca escolhendo sempre a opção mais restrita.
     */
    private ColunaCabecalho escolherColuna() {
        ColunaCabecalho melhor = null;

        for (No atual = cabecalhoRaiz.direita; atual != cabecalhoRaiz; atual = atual.direita) {
            ColunaCabecalho coluna = (ColunaCabecalho) atual;
            if (melhor == null || coluna.tamanho < melhor.tamanho) {
                melhor = coluna;
            }
        }

        return melhor;
    }

    /**
     * Executa o Algorithm X e devolve a lista de nós solução (um nó por
     * linha escolhida - o "idLinha" de cada um identifica qual jogada foi
     * feita), ou null se não houver solução.
     *
     * Estrutura geral (recursiva):
     *  1. se não sobrou nenhuma coluna, a solução parcial atual é completa;
     *  2. escolher a coluna mais restrita e cobri-la;
     *  3. para cada linha que satisfaz essa coluna, tentar incluí-la na
     *     solução, cobrir as colunas relacionadas, e chamar buscar()
     *     recursivamente;
     *  4. se a recursão falhar, descobrir as colunas relacionadas e tentar
     *     a próxima linha (backtrack);
     *  5. se nenhuma linha funcionar, descobrir a coluna escolhida e
     *     devolver falha.
     */
    public List<No> buscar() {
        List<No> solucaoParcial = new ArrayList<>();

        if (buscarRecursivo(solucaoParcial)) {
            return solucaoParcial;
        }

        return null;
    }

    /**
     * Faz o trabalho pesado da recursão do Algorithm X, acumulando os nós
     * escolhidos em "solucaoParcial". Devolve true assim que uma solução
     * completa é encontrada (nesse caso, "solucaoParcial" já contém o
     * resultado); devolve false se este ramo da busca não leva a nenhuma
     * solução (nesse caso, "solucaoParcial" é devolvida ao estado em que
     * estava antes da chamada, sem nenhum nó extra).
     */
    private boolean buscarRecursivo(List<No> solucaoParcial) {
        if (cabecalhoRaiz.direita == cabecalhoRaiz) {
            // Não sobrou nenhuma coluna na fileira de cabeçalhos - todas as
            // restrições já foram satisfeitas, então a solução está completa.
            return true;
        }

        ColunaCabecalho coluna = escolherColuna();
        coluna.cobrir();

        for (No linha = coluna.baixo; linha != coluna; linha = linha.baixo) {
            solucaoParcial.add(linha);

            for (No no = linha.direita; no != linha; no = no.direita) {
                no.coluna.cobrir();
            }

            if (buscarRecursivo(solucaoParcial)) {
                return true;
            }

            // Backtrack: esta linha não levou a uma solução, desfaz na
            // ordem inversa e tenta a próxima linha candidata.
            solucaoParcial.remove(solucaoParcial.size() - 1);
            for (No no = linha.esquerda; no != linha; no = no.esquerda) {
                no.coluna.descobrir();
            }
        }

        coluna.descobrir();
        return false;
    }
}