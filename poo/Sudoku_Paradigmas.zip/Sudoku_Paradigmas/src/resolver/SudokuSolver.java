package resolver;

import java.util.List;

import Objeto.Tabuleiro;

/**
 * Fachada de resolução: ponto de entrada único para resolver um Sudoku via
 * Algorithm X com Dancing Links. Orquestra o ConstrutorCoberturaSudoku (que
 * sabe traduzir Sudoku para cobertura exata) e a MatrizCoberturaExata (que
 * sabe resolver cobertura exata), sem se envolver nos detalhes de nenhum
 * dos dois.
 *
 * Ocupa, na arquitetura, o papel que "resolverSudoku" tinha no código em C
 * - mas aqui é só um orquestrador magro; toda a lógica pesada mora nas
 * outras três classes (No, ColunaCabecalho, MatrizCoberturaExata) e na
 * tradução de domínio (ConstrutorCoberturaSudoku).
 */
public class SudokuSolver {

    /**
     * Tenta resolver o tabuleiro informado. Devolve um novo Tabuleiro
     * preenchido em caso de sucesso, ou null se o tabuleiro não tiver
     * solução. O tabuleiro original não é modificado.
     */
    public static Tabuleiro resolver(Tabuleiro tabuleiro) {
        ConstrutorCoberturaSudoku construtor = new ConstrutorCoberturaSudoku();
        MatrizCoberturaExata matriz = construtor.construir(tabuleiro);

        List<No> solucao = matriz.buscar();

        if (solucao == null) {
            return null;
        }

        return construtor.aplicarSolucao(solucao);
    }
}