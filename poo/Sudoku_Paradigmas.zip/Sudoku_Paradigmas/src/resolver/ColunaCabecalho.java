package resolver;

/**
 * Representa uma coluna da matriz de cobertura exata (uma restrição a ser
 * satisfeita exatamente uma vez: uma célula preenchida, um dígito numa
 * linha, um dígito numa coluna, ou um dígito num bloco).
 *
 * É também um "No" especial: além de apontar para vizinhos esquerda/direita
 * (a fileira de cabeçalhos de coluna), ela é o topo da sua própria coluna
 * vertical de nós.
 *
 * As operações "cobrir" e "descobrir" são o coração do Algorithm X:a própria coluna sabe como se
 * remover e se devolver à malha - o comportamento pertence ao objeto que
 * ele afeta.
 */
public class ColunaCabecalho extends No {

    /**
     * Quantidade de nós atualmente presentes nesta coluna. Usado pela
     * heurística de escolha de coluna (equivalente em espírito ao MRV do
     * código em C: escolher sempre a coluna com menos opções restantes).
     */
    public int tamanho;

    /**
     * Nome da restrição, útil para depuração (ex: "celula-3-5",
     * "linha-3-digito-7", "coluna-5-digito-7", "bloco-2-digito-7").
     */
    public String nome;

    public ColunaCabecalho(String nome) {
        this.nome = nome;
        this.tamanho = 0;
        this.coluna = this;
        
        this.esquerda = this;
        this.direita = this;
        this.cima = this;
        this.baixo = this;
    }

    /**
     * Remove esta coluna da fileira de cabeçalhos e remove, de todas as
     * outras colunas, qualquer nó que esteja na mesma linha que algum nó
     * desta coluna. Isso "marca como satisfeita" a restrição representada
     * por esta coluna, sem apagar nada da memória - os nós continuam
     * existindo, só saem temporariamente da malha (podem ser devolvidos
     * por descobrir()).
     */
    public void cobrir() {
        this.removerDaLinha();

        for (No linha = this.baixo; linha != this; linha = linha.baixo) {
            for (No no = linha.direita; no != linha; no = no.direita) {
                no.removerDaColuna();
                no.coluna.tamanho--;
            }
        }
    }

    /**
     * Desfaz exatamente o que cobrir() fez, na ordem inversa - devolve
     * esta coluna e os nós relacionados à malha.
     */
    public void descobrir() {
    	

        for (No linha = this.cima; linha != this; linha = linha.cima) {
            for (No no = linha.esquerda; no != linha; no = no.esquerda) {
                no.coluna.tamanho++;
                no.reinserirNaColuna();
            }
        }
        this.reinserirNaLinha();
        // TODO: para cada nó "linha" subindo por esta coluna (ordem
        // inversa de cobrir()), e para cada nó "no" percorrendo a linha à
        // esquerda a partir de "linha":
        //   no.coluna.tamanho++; no.reinserirNaColuna();
        // TODO: reinserirNaLinha() no cabeçalho desta coluna.
    }
}