/**
 * 
 */
/**
 * 
 */
module Sudoku_Paradigmas {
	requires java.desktop;
}